/**
 * Created by admin on 2015/11/9.
 */

$(document).ready(function(){
    $(".flip-container .back").css("display","none");
});